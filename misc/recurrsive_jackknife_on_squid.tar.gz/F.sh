for (( i=1; i<32; i=i+1 ));do
  iT=$(printf "%02d" $i)
  ./bin/cart2sphr -n 32 -d result/c4pt/mc-td/$iT -p "txt" result/c4pt/mc-td/binary/$iT/*
  ./bin/cart2sphr -n 32 -d result/l4pt/mc-td/$iT -p "txt" result/l4pt/mc-td/binary/$iT/*
done

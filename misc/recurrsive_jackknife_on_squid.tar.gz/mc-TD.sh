#!/bin/bash
# version: 1.0

if [ $# != 4 ]; then
    echo "USAGE: $(basename $0) [XYZSIZE] [TSIZE] [X4PT] [CONF]"
    exit 1
fi

ulimit -n 1024
XYZSIZE=$1
TSIZE=$2
X4PT=$3
CONF=$4

ROOT=.
BIN_DIR=$ROOT/bin
DATA_DIR=$ROOT/data
REC_DIR=$DATA_DIR/$X4PT/recursive

ARRAY_LENGTH=$(($XYZSIZE * $XYZSIZE * $XYZSIZE))
T_HALF=$(($TSIZE / 2))

CONF_LBASE=${CONF##*.}
CONF=${CONF_LBASE#*-}

O_DIR=result/$X4PT/mc-td

for (( iT=1; iT<$T_HALF; iT=iT+1 )); do
  T=$(printf "%02d" $iT)
  echo $T

  # mkdir -p $O_DIR/$T
  mkdir -p $O_DIR/binary/$T
  mkdir -p $O_DIR/$T

  SAMPLE_DIR=$REC_DIR/$CONF/jsample
  LAP_DIR=$REC_DIR/$CONF/lap
  FKS_DIR=$REC_DIR/$CONF/fks-td

  # F_{KS} (time-dependent)
  echo "#######################################"
  echo -e "##  FKS: $T-$CONF..."
  echo "#######################################"

  tm=$(printf "%02d" $(($iT - 1)))
  tp=$(printf "%02d" $(($iT + 1)))

  rm -rf $FKS_DIR/$T
  mkdir -p $FKS_DIR/$T

  for psgauge in $(ls $SAMPLE_DIR/ps/$T); do
    ogauge=${psgauge/.ps./.}
    vgauge=${psgauge/.ps./.v.}
    vm=${vgauge/+$T/+$tm}
    vp=${vgauge/+$T/+$tp}
    psm=${psgauge/+$T/+$tm}
    psp=${psgauge/+$T/+$tp}

    $BIN_DIR/fks-td -l $ARRAY_LENGTH -o $FKS_DIR/$T/$ogauge $SAMPLE_DIR/v/$tm/$vm $SAMPLE_DIR/v/$tp/$vp $SAMPLE_DIR/ps/$tm/$psm $SAMPLE_DIR/ps/$tp/$psp $LAP_DIR/v/$T/$vgauge $LAP_DIR/ps/$T/$psgauge >/dev/null 2>&1
  done
  echo " "

  # Jackknife and finalize part
  echo -e "Jackknife average $FKS_DIR/$T..."
  $BIN_DIR/mean -j -l $ARRAY_LENGTH -o $O_DIR/binary/$T/$CONF $FKS_DIR/$T/4pt.*
  echo " "
done


echo " "
echo "$CONF_BASE finished!"

#!/bin/bash
# version: 1.0

if [ $# != 4 ]; then
    echo "USAGE: $(basename $0) [XYZSIZE] [TSIZE] [X4PT] [CONF]"
    exit 1
fi

ulimit -n 1024
XYZSIZE=$1
TSIZE=$2
X4PT=$3
CONF=$4

ROOT=.
BIN_DIR=$ROOT/bin
DATA_DIR=$ROOT/data
A1_DIR=$DATA_DIR/$X4PT/a1plus

ARRAY_LENGTH=$(($XYZSIZE * $XYZSIZE * $XYZSIZE))
T_HALF=$(($TSIZE / 2))

CONF_LBASE=${CONF##*.}
CONF_BASE=${CONF_LBASE#*-}

REC_DIR=$DATA_DIR/$X4PT/recursive
O_DIR=result/$X4PT/mc-td

# Recursive Jackknife resampling & laplacian
for (( iT=0; iT<=$T_HALF; iT=iT+1 )); do
  T=$(printf "%02d" $iT)
  for type in $(ls $A1_DIR); do

    all_config=($(ls $A1_DIR/$type/$T))
    N=${#all_config[@]}
    CONF_THIS=4pt.$type.+$T.$CONF
    # Remove current configuration from list
    for (( i=0; i<$N; i=i+1 )); do
      if [ ${all_config[$i]} == $CONF_THIS ]; then
        all_config[$i]=""
      else
        all_config[$i]=$A1_DIR/$type/$T/${all_config[$i]}
      fi
    done

    # Jackknife resample
    echo -e "JR: $type-$T-$CONF_BASE..."
    JR_DIR=$REC_DIR/$CONF_BASE/jsample
    rm -rf $JR_DIR/$type/$T
    mkdir -p $JR_DIR/$type/$T
    $BIN_DIR/jre -l $ARRAY_LENGTH -d $JR_DIR/$type/$T ${all_config[@]}

    # Calculate laplacian
    echo -e "LAP: $type-$T-$CONF_BASE..."
    LAP_DIR=$REC_DIR/$CONF_BASE/lap
    rm -rf $LAP_DIR/$type/$T
    mkdir -p $LAP_DIR/$type/$T
    $BIN_DIR/prev -n $XYZSIZE -d $LAP_DIR/$type/$T $JR_DIR/$type/$T/*
  done
done

# Calculate F_{KS}
for (( iT=1; iT<$T_HALF; iT=iT+1 )); do
  T=$(printf "%02d" $iT)

  # mkdir -p $O_DIR/$T
  mkdir -p $O_DIR/binary/$T

  SAMPLE_DIR=$REC_DIR/$CONF/jsample
  LAP_DIR=$REC_DIR/$CONF/lap
  FKS_DIR=$REC_DIR/$CONF/fks-td

  # F_{KS} (time-dependent)
  echo "#######################################"
  echo -e "##  FKS: $T-$CONF..."
  echo "#######################################"

  tm=$(printf "%02d" $(($iT - 1)))
  tp=$(printf "%02d" $(($iT + 1)))

  rm -rf $FKS_DIR/$T
  mkdir -p $FKS_DIR/$T

  for psgauge in $(ls $SAMPLE_DIR/ps/$T); do
    ogauge=${psgauge/.ps./.}
    vgauge=${psgauge/.ps./.v.}
    vm=${vgauge/+$T/+$tm}
    vp=${vgauge/+$T/+$tp}
    psm=${psgauge/+$T/+$tm}
    psp=${psgauge/+$T/+$tp}

    $BIN_DIR/fks-td -l $ARRAY_LENGTH -o $FKS_DIR/$T/$ogauge $SAMPLE_DIR/v/$tm/$vm $SAMPLE_DIR/v/$tp/$vp $SAMPLE_DIR/ps/$tm/$psm $SAMPLE_DIR/ps/$tp/$psp $LAP_DIR/v/$T/$vgauge $LAP_DIR/ps/$T/$psgauge >/dev/null 2>&1
  done

  rm -rf $JR_DIR/$type/$tm
  rm -rf $LAP_DIR/$type/$tm

  # Jackknife and finalize part
  echo -e "Jackknife average $FKS_DIR/$T..."
  $BIN_DIR/mean -j -l $ARRAY_LENGTH -o $O_DIR/binary/$T/$CONF $FKS_DIR/$T/4pt.*
  echo " "
done

echo " "
echo "$CONF_BASE finished!"

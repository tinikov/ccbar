#!/bin/bash
# version: 1.0

mkdir -p prejobs
mkdir -p tdjobs
mkdir -p prelogs
mkdir -p tdlogs

# Coulomb
for conf in $(ls data/c4pt/a1plus/ps/00); do
  lbase=${conf/4pt.ps.+00.gfix_C./}
  sbase=${lbase#*-}
  conf=gfix_C.$lbase
  prejob=prejobs/C-$sbase.job
  tdjob=tdjobs/C-$sbase.job

  echo -e "\
#!/bin/bash
#---------- qsub option ----------\n\
#PBS -q SQUID\n\
#PBS --group=G14458\n\
#PBS -l elapstim_req=00:30:00\n\
#--------- program exec ---------\n\
module load BaseCPU\n\
cd \$PBS_O_WORKDIR\n\
\n\
./preRJ.sh 32 64 c4pt $conf > prelogs/C-$sbase.txt 2>&1" > $prejob

  echo -e "\
#!/bin/bash
#---------- qsub option ----------\n\
#PBS -q SQUID\n\
#PBS --group=G14458\n\
#PBS -l elapstim_req=08:00:00\n\
#--------- program exec ---------\n\
module load BaseCPU\n\
cd \$PBS_O_WORKDIR\n\
\n\
./mc-TD.sh 32 64 c4pt $conf > tdlogs/C-$sbase.txt 2>&1" > $tdjob
done

# Landau
for conf in $(ls data/l4pt/a1plus/ps/00); do
  lbase=${conf/4pt.ps.+00.gfix_L./}
  sbase=${lbase#*-}
  conf=gfix_L.$lbase
  prejob=prejobs/L-$sbase.job
  tdjob=tdjobs/L-$sbase.job

  echo -e "\
#!/bin/bash
#---------- qsub option ----------\n\
#PBS -q SQUID\n\
#PBS --group=G14458\n\
#PBS -l elapstim_req=00:30:00\n\
#--------- program exec ---------\n\
module load BaseCPU\n\
cd \$PBS_O_WORKDIR\n\
\n\
./preRJ.sh 32 64 l4pt $conf > prelogs/L-$sbase.txt 2>&1" > $prejob

  echo -e "\
#!/bin/bash
#---------- qsub option ----------\n\
#PBS -q SQUID\n\
#PBS --group=G14458\n\
#PBS -l elapstim_req=08:00:00\n\
#--------- program exec ---------\n\
module load BaseCPU\n\
cd \$PBS_O_WORKDIR\n\
\n\
./mc-TD.sh 32 64 l4pt $conf > tdlogs/L-$sbase.txt 2>&1" > $tdjob
done
